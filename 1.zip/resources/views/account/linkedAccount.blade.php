    <div class="page-header">
        <h3>Linked Accounts</h3>
    </div>


    <p><a href="{{ url('auth/google') }}">Link your Google account</a></p>
    <p><a href="{{ url('auth/facebook') }}">Link your Facebook account</a></p>
    <p><a href="{{ url('auth/twitter') }}">Link your Twitter account</a></p>
    <p><a href="{{ url('auth/github') }}">Link your Github account</a></p>
    <p><a href="{{ url('auth/linkedin') }}">Link your LinkedIn account</a></p>