@extends('layouts.master')

@section('content')
    <div class="main-container">
         <h1>Azure Pipelines and PHP</h1>
         <p class="lead">A boilerplate for Laravel web applications.</p>

         <hr>

         <div class="row">
            <div class="col-sm-6">
                <h2>Heading</h2>
                <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
                <p><a href="#" role="button" class="btn btn-default">View details »</a></p>
            </div>
            <div class="col-sm-6">
                <h2>Heading</h2>
                <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
                <p><a href="#" role="button" class="btn btn-default">View details »</a></p>
            </div>
            <div class="col-sm-6">
                <h2>Heading</h2>
                <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
                <p><a href="#" role="button" class="btn btn-default">View details »</a></p>
            </div>
            <div class="col-sm-6">
                <h2>Heading</h2><p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
                <p><a href="#" role="button" class="btn btn-default">View details »</a></p>
            </div>
        </div>
    </div>
@stop